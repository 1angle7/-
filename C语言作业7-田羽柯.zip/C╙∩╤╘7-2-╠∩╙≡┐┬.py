import tkinter as tk
from tkinter import messagebox

class TreeNode:
    def __init__(self, weight, parent=None, lchild=None, rchild=None):
        self.weight = weight
        self.lchild = lchild
        self.rchild = rchild
        self.parent = parent

def compare(weights):
    nodes = [TreeNode(weight) for weight in weights]
    nodes.sort(key=lambda x: x.weight)

    for _ in range(len(weights) - 1):
        min1, min2 = nodes.pop(0), nodes.pop(0)
        new_node = TreeNode(min1.weight + min2.weight, lchild=min1, rchild=min2)
        min1.parent, min2.parent = new_node, new_node
        nodes.append(new_node)
        nodes.sort(key=lambda x: x.weight)  # 重新排序

    return nodes[0]

def draw_tree(canvas, node, x, y, h_dist, v_dist):
    if node is not None:
        canvas.create_oval(x-20, y-40, x+20, y+40, outline="green")
        canvas.create_text(x, y, text=str(node.weight))
        if node.lchild is not None:
            draw_tree(canvas, node.lchild, x - h_dist, y + v_dist, h_dist / 2, v_dist)
            canvas.create_line(x, y, x - h_dist, y + v_dist, fill="green")
        if node.rchild is not None:
            draw_tree(canvas, node.rchild, x + h_dist, y + v_dist, h_dist / 2, v_dist)
            canvas.create_line(x, y, x + h_dist, y + v_dist, fill="green")

# 创建一个窗口
win = tk.Tk()
win.title("哈夫曼树")
messagebox.showinfo("欢迎", "欢迎来到哈夫曼树世界！")
canvas = tk.Canvas(win, width=800, height=800)
canvas.pack()

# 创建一个简单的哈夫曼树
weights = [3, 14, 8, 7, 8]
root = compare(weights)

# 绘制哈夫曼树
draw_tree(canvas, root, 400, 200, 150, 150)

# 显示窗口
win.mainloop()
