def calculate_weights(input_file):
    # 打开原始文本文件并读取内容
    with open(input_file, 'r', encoding='utf-8') as f:
        text = f.read()

    # 统计每个字符的出现次数
    weights = {}
    for char in text:
        if char in weights:
            weights[char] += 1
        else:
            weights[char] = 1

    return weights


def write_weights(output_file, weights):
    # 将字符及其对应的权重写入到另一个文本文件中
    with open(output_file, 'w', encoding='utf-8') as f:
        for char, weight in weights.items():
            f.write(f"{char}: {weight}\n")


def main():
    input_file = "三国演义.txt"  # 原始文本文件
    output_file = "个数.txt"  # 权重文本文件

    # 计算字符权重
    weights = calculate_weights(input_file)
    # 将权重写入文件
    write_weights(output_file, weights)

main()
