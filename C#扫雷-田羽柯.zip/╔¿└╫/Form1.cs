﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 扫雷
{
    public partial class Form1 : Form
    {
        private int costTime;//计时
        private int mineWide = 30;
        private int mineNum = 10;
        private int xNum = 8;
        private int yNum = 9;
        private int[,] flags;
        private int[,] MINES;

        private Button[,] mineBtns;
        public Form1()
        {
            InitializeComponent();
            label2.Text=mineNum.ToString();
            flags=new int[xNum,yNum];
            MINES=new int[xNum,yNum];
            mineBtns=new Button[xNum,yNum];
            for (int x = 0; x < xNum; x++)
            {
                for (int y = 0; y < yNum; y++)
                {
                    mineBtns[x, y] = new Button();
                    Controls.Add(mineBtns[x, y]);
                    mineBtns[x,y].Location=new Point(45+mineWide*x,90+mineWide*y);
                    mineBtns[x, y] .Width= mineWide;
                    mineBtns[x,y] .Height= mineWide;
                    mineBtns[x, y].Name = "Mines_" + x.ToString() + "_" + y.ToString();
                    mineBtns[x, y].Visible = false;
                    mineBtns[x, y].MouseUp += mineBtn_MouseUp;
                    mineBtns[x, y].BackgroundImageLayout = ImageLayout.Stretch;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            GameInit();
            timer1.Start();
        }
        private void GameInit()
        {
            for (int x = 0; x < xNum; x++)
            {
                for (int y = 0; y < yNum; y++)
                {
                    mineBtns[x, y].Text = "";
                    mineBtns[x, y].Visible = true;
                    mineBtns[x,y].Enabled=true;
                    mineBtns[x,y].BackgroundImage=null;
                    MINES[x, y] = 0;
                }
            }
            layMines();
        }

        private void layMines()
        { 
            Random ra=new Random();
            int x, y;
            for (int i = 0; i < mineNum;)
            { 
                x=ra.Next(xNum);
                y=ra.Next(yNum);
                if (MINES[x, y] == 0)
                {
                    MINES[x, y] = 1;
                    i++;
                }
            }
        }

        //获取按钮周围的雷数目
        private int getAroundMindCount(int x, int y)
        { 
            int count = 0;
            int xMin = (x == 0) ? 0 : x - 1;
            int yMin = (y == 0) ? 0 : y - 1;
            int xMax = (x == xNum-1) ? xNum-1 : x +1;
            int yMax = (y == yNum - 1) ? yNum-1 : y + 1;
            for(int i=xMin;i<=xMax;i++)
            {
                for(int j=yMin; j<yMax;j++)
                {
                    count += MINES[i, j];
                }
            }

            return count;
        }

        //对周围数目为0的按钮进行展开，直到不为0或边界为止
        private void ExpendMines(int x,int y)
        {
            int xMin = (x == 0) ? 0 : x - 1;
            int yMin = (y == 0) ? 0 : y - 1;
            int xMax = (x == xNum - 1) ? xNum - 1 : x + 1;
            int yMax = (y == yNum - 1) ? yNum - 1 : y + 1;
            for (int i = xMin; i <= xMax; i++)
            {
                for (int j = yMin; j < yMax; j++)
                {
                    if (mineBtns[i, j].Enabled ==false)
                        continue;
                    int count = getAroundMindCount(i, j);
                    if (count == 0)
                    {
                        mineBtns[i, j].Enabled = false;
                        ExpendMines(i,j);
                    }
                    else
                    {
                        mineBtns[i, j].Text = count.ToString();
                        mineBtns[i, j].Enabled = false;
                    }
                }
            }
        }

        //胜利的判定
        private Boolean IsVictory()
        {
            for (int x = 0; x < xNum; x++)
            {
                for (int y = 0; y < yNum; y++)
                {
                    if (mineBtns[x, y].Enabled && flags[x,y]!=1)
                        return false;
                    if (MINES[x, y] == 0 && flags[x,y]==1)
                        return false;
                }
            }
            return true;
        }

        //踩雷之后显示所有的区域
        private void showAll()
        {
            for (int x = 0; x < xNum; x++)
            {
                for (int y = 0; y < yNum; y++)
                {
                    int count = getAroundMindCount(x, y);
                    if(count != 0)
                        mineBtns[x,y].Text= count.ToString();
                    if (MINES[x, y] == 1)
                    {
                        mineBtns[x, y].Text = "";
                       mineBtns[x, y].BackgroundImage = Image.FromFile("mine.png");
                    }
                    mineBtns[x, y].Enabled = false;
                }
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            costTime++;
            label1.Text = costTime.ToString();
        }
        /// <summary>
        /// 雷的按钮的事件
        /// </summary>
        /// <param name="sender">通过sender参数可以知道是那个按钮发出的事件</param>
        /// <param name="e">通过e参数可以知道是左键还是右键单击的</param>
        private void mineBtn_MouseUp(object sender,MouseEventArgs e)
        { 
            Button btn = (Button)sender;
            String[] str = btn.Name.Split('_');
            int x = Convert.ToInt16(str[1]);
            int y = Convert.ToInt16(str[2]);

            switch (e.Button) 
            {
                case MouseButtons.Left:
                    {
                        if (flags[x, y] == 0)
                        {
                            if (MINES[x, y] == 1)//如果挖到雷
                            {
                                showAll();
                                btn.BackgroundImage = Image.FromFile("mine.png");
                                MessageBox.Show("失败！！！", "结束");
                                timer1.Stop();
                            }
                            else //没有挖到雷
                            {
                                btn.BackgroundImage = null;
                                int count = getAroundMindCount(x, y);
                                if (count != 0)
                                {
                                    btn.Text = count.ToString();
                                    btn.Enabled = false;
                                }
                                else
                                {
                                    ExpendMines(x, y);
                                }
                                //判断是否胜利
                                if (IsVictory())
                                {
                                    timer1.Stop();
                                    MessageBox.Show("胜利！！！", "结束");
                                }
                            }
                        }
                    }
                    break;
                case MouseButtons.Right:
                    if (flags[x, y] == 1)
                    {
                        flags[x, y] = 0;
                        btn.BackgroundImage = null;
                        mineNum++;
                    }
                    else
                    {
                        flags[x, y] = 1;
                        btn.BackgroundImage = Image.FromFile("flag.png");
                        mineNum--;
                    }
                    label2.Text=mineNum.ToString();
                    //判断是否胜利
                    if (IsVictory())
                    {
                        timer1.Stop();
                        MessageBox.Show("胜利！！！", "结束");
                    }
                    break;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
