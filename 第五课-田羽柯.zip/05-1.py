import openpyxl

# 打开Excel文件
workbook = openpyxl.load_workbook('成绩表.xlsx')

# 选择要导出的工作表
sheet1 = workbook['598854']
sheet2 = workbook['598856']
sheet3 = workbook['598858']

# 打开文本文件进行写入
with open('598854.txt', 'w', encoding='utf-8') as file1:
    for row in sheet1:
        row_values = [cell.value for cell in row]
        file1.write('，'.join(str(value) for value in row_values) + '\n')

with open('598856.txt', 'w', encoding='utf-8') as file2:
    for row in sheet2:
        row_values = [cell.value for cell in row]
        file2.write('，'.join(str(value) for value in row_values) + '\n')

with open('598858.txt', 'w', encoding='utf-8') as file3:
    for row in sheet3:
        row_values = [cell.value for cell in row]
        file3.write('，'.join(str(value) for value in row_values) + '\n')