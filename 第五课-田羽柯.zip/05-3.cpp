#include<stdio.h>
#include<string.h>
#include <stdlib.h>

struct student{
	int number;
	int Student_Id;
	char name[10];
	char sex[10] ;
	char class_Id[10];
	int test_1;
	int test_2;
	int test_3;	
};



int main()
{   while(1){

    char filename[20 ];
    struct student st[1000];
    char A[3][7]={"598858","598856","598854"};
    char ch,str[10];
    printf("��������Ҫ�����˵����ֻ���ѧ�ţ�");
    
    gets(str);
    int number_student = atoi(str);

    for (int a =0 ; a<3; a++){
    	
	sprintf(filename, "%s�γ�.txt", A[a]);

    FILE* fp = fopen(filename, "r");
	char ch[200] ;
	fgets(ch,200,fp);
	int num=0;
	char result;
	while(fgets(ch,200,fp)){
                         
    char *token = strtok(ch, ",");

    // ������
    int count = 0;                     
                         
     while (token != NULL) {
        switch (count) {
            case 0:
                st[num].number = atoi(token);
                break;
            case 1:
                st[num].Student_Id = atoi(token);
                break;
            case 2:
                strcpy(st[num].name, token);
                break;
            case 3:
                strcpy(st[num].sex, token);
                break;
            case 4:
                strcpy(st[num].class_Id, token);
                break;
            case 5:
            	st[num].test_1 = atoi(token);
            case 6:
            	st[num].test_2 = atoi(token);
            case 7:
                st[num].test_3 = atoi(token);
               
            default:
                break;
        }

        // ��ȡ��һ���ֶ�
        token = strtok(NULL, ",");
        count++;
    }
	                    
	num++;
	}
	fclose(fp);
	for (int m=0;m<num;m++){
		float average_score=(st[m].test_1+st[m].test_2+st[m].test_3)/3.00 ;
		if(number_student==st[m].Student_Id||strcmp(str,st[m].name)==0) {
		printf("���  ѧ��         ����     �Ա�    ������          ����ת��    �����ת��  ��ֵ�����߼�����  ƽ����  \n");

		printf( "%d     %d    %s   %s      %s     %d         %d         %d               %.2f\n",
                m + 1, st[m].Student_Id, st[m].name, st[m].sex, st[m].class_Id,
                st[m].test_1, st[m].test_2, st[m].test_3, average_score);

	}}
	
}}
return 0;
}
