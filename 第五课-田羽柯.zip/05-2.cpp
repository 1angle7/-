#include <stdio.h>  
#include <stdlib.h>  
  
#define MAX_LINE_LENGTH 1000  
  
int main() {  
    FILE *inputFiles[3], *outputFiles[3];  
    char line[MAX_LINE_LENGTH];  
    struct {  
        double data[8];  
        double sum;  
    } record;  
  
    // �����������ļ�  
    inputFiles[0] = fopen("598854.txt", "r");  
    inputFiles[1] = fopen("598856.txt", "r");  
    inputFiles[2] = fopen("598858.txt", "r");  
    outputFiles[0] = fopen("598854 - ����.txt", "w");  
    outputFiles[1] = fopen("598856 - ����.txt", "w");  
    outputFiles[2] = fopen("598858 - ����.txt", "w");  
  
    if (inputFiles[0] == NULL || inputFiles[1] == NULL || inputFiles[2] == NULL || outputFiles[0] == NULL || outputFiles[1] == NULL || outputFiles[2] == NULL) {  
        perror("Error opening files");  
        exit(1);  
    }  
  
    // ѭ������ÿ���ļ�������  
    for (int i = 0; i < 3; i++) {  
        while (fgets(line, MAX_LINE_LENGTH, inputFiles[i]) != NULL) {  
            sscanf(line, "%lf %lf %lf %lf %lf %lf %lf %lf", &record.data[0], &record.data[1], &record.data[2], &record.data[3], &record.data[4], &record.data[5], &record.data[6], &record.data[7]);  
            if (record.data[0] == 'N' || record.data[0] == 'n' || record.data[0] == ' ') { // None or space  
                record.data[0] = 0;  
            }  
            if (record.data[1] == 'N' || record.data[1] == 'n' || record.data[1] == ' ') { // None or space  
                record.data[1] = 0;  
            }  
            if (record.data[2] == 'N' || record.data[2] == 'n' || record.data[2] == ' ') { // None or space  
                record.data[2] = 0;  
            }  
            if (record.data[3] == 'N' || record.data[3] == 'n' || record.data[3] == ' ') { // None or space  
                record.data[3] = 0;  
            }  
            if (record.data[4] == 'N' || record.data[4] == 'n' || record.data[4] == ' ') { // None or space  
                record.data[4] = 0;  
            }  
            if (record.data[5] == 'N' || record.data[5] == 'n' || record.data[5] == ' ') { // None or space  
                record.data[5] = 0;  
            }  
            if (record.data[6] == 'N' || record.data[6] == 'n' || record.data[6] == ' ') { // None or space  
                record.data[6] = 0;  
            }  
            if (record.data[7] == 'N' || record.data[7] == 'n' || record.data[7] == ' ') { // None or space  
                record.data[7] = 0;  
            }  
            record.sum = record.data[6] + record.data[7]; // ������������ڰ��е�ƽ����֮�ͣ�������д��ھ��У���������ֱ�Ӹ��ǵ������е����ݣ�  
            fprintf(outputFiles[i], "%.2lf %.2lf %.2lf %.2lf %.2lf %.2lf %.2lf %.
