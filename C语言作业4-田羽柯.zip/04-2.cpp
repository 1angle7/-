#include <stdlib.h>
#include <string.h>
#include <stdio.h>
int evalRPN(char ** tokens, int tokensSize){
    int stack[tokensSize];                                              //����ջ
    int top = -1;                                                       //ջ��ָ��

    for(int i=0; i < tokensSize; ++i){                                  //������׺����ʽ�ַ���
        char* token = tokens[i];
        if((token[0] >= '0' && token[0] <= '9') || strlen(token) > 1){  
            stack[++top] = atoi(token);                                 //���ַ�ת��Ϊint������
        }else{                                                          //��Ϊ�����
            switch(token[0]){
                case'+':
                    stack[top-1] = stack[top-1] + stack[top];           
                    break;
                case'-':
                    stack[top-1] = stack[top-1] - stack[top];
                    break;
                case'*':
                    stack[top-1] = stack[top-1] * stack[top];
                    break;
                case'/':
                    stack[top-1] = stack[top-1] / stack[top];
                    break;
            }
            --top;
        }
    }

    return stack[top];                                                  //���ս��Ϊջ��Ԫ��
}

int main() {
    char *tokens[] = {"10", "6", "9", "3", "+", "-11", "*", "/", "*", "17", "+", "5", "+"};
    int tokensSize = sizeof(tokens) / sizeof(tokens[0]);
    int result = evalRPN(tokens, tokensSize);
    printf("��������%d\n", result);
    return 0;
}
