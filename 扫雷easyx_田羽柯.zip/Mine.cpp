#include "Mine.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

Mine::Mine()
{//��ʼ��mine����
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			mine[i][j] = 0;
		}
	}
	/*
	srand(time(NULL));
	for (int i = 0; i < 10;)
	{
		int r = rand() % 10;
		int c = rand() % 10;

		if (mine[r][c] == 0)
		{
			mine[r][c] = -1;
			i++;
		}
	}
	
	int count = 0;
	for (int x = 0; x < 10; x++)
	{
		for (int y = 0; y < 10; y++) {
			for (int i = x - 1; i <= x + 1; i++) {
				for (int k = y - 1; k <= y + 1; k++) {
					if (i>=0&&i<10&&k>=0&&k<10 && mine[i][k] == -1)
						count++;
				}
			}
			mine[x][y] = count;
		}
	}
	*/
}
//�������ʮ����
void Mine::lei()
{
	srand(time(NULL));
	for (int i = 0; i < 10;)
	{
		int r = rand() % 10;
		int c = rand() % 10;

		if (mine[r][c] == 0)
		{
			mine[r][c] = -1;
			i++;
		}
	}
}
/*
bool Mine::IsTure(int x,int y)
{
	return(x >= 0 && x < 10 && y >= 0 && y < 10);
}

int Mine::CountMine(int x,int y)
{
	int i;
	int k;
	void lei();
	bool IsTure(int i,int k);
	int count = 0;
	for (i = x - 1; i <= x + 1; i++) {
		for (k = y - 1; k <= y + 1; k++) {
			if (IsTure(i, k) && mine[i][k] == -1)
				count++;
		}
	}
	return count;
}
*/
//�������Ա��м����׷ŵ�mine��������
void Mine::LeiNumber()
{
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++) {
			int count = 0;
			for (int a = i - 1; a <= i + 1; a++) {
				for (int k = j - 1; k <= j + 1; k++) {
					if (a>=0&&a<10&&k>=0&&k<10 && mine[a][k] == -1)
						count++;
				}
			}
			if (mine[i][j] != -1)
				mine[i][j] = count;
		}
	}
}



