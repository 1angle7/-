#pragma once
class Mine//�൱���ʼ��view��ֵ
{
public:
	Mine();
	void lei();
	void LeiNumber();
	int mine[10][10];
	//int LeiNumber(int x, int y);
private:
	/*
	void lei();
	int CountMine(int x, int y);
	bool IsTure(int x, int y);
	*/
};

