#ifndef GAME_H
#define GAME_H
#include <graphics.h>
#include <conio.h>
#include <easyx.h>
#include "Mine.h"

class Game
{
public:
	int view[10][10];
	IMAGE imgs[12];

	Game();
	void leis();
	//void loadResource();//���׺�����ȫ������ס 
	void showview();//������� 
	Mine mines;
	void Dianji();
	void Mouse(ExMessage* msg, int view[][10]);
	void Boom(int view[][10], int x, int y);
	int judge(int view[][10], int x, int y);
	void Qipan();
private:
	ExMessage msg;
	int a = msg.x;
	int b = msg.y;
};

#endif