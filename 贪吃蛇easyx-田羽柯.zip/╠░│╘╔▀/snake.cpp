#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>

#define WIDTH 800
#define HEIGHT 600
#define SNAKE_NUM  500
enum DIR//�ߵķ���
{
	UP,
	DOWN,
	LEFT,
	RIGHT,
};
struct Snake
{
	int size;//�ж��ٽ�
	POINT coor[SNAKE_NUM];
	int dir;//����
	int speed;//�ٶ�
	int score;//����
}snake;
struct Food
{
	int x;
	int y;
	int r;
	int flag;//�Ƿ񱻳Ե�
	COLORREF color;
}food;
//��ʼ������
void GameInit()
{
	//�������������
	srand(GetTickCount());
	//��ʼ����
	snake.dir = DIR::RIGHT;
	snake.score = 0;
	snake.size = 3;
	snake.speed = 10;
	snake.coor[2].x=10;
	snake.coor[2].y=10;
	snake.coor[1].x = 20;
	snake.coor[1].y = 10;
	snake.coor[0].x = 30;
	snake.coor[0].y = 10;
	//��ʼ��ʳ��
	food.color = RGB(rand() % 256, rand() % 256, rand() % 256);
	food.flag = 1;
	food.r = rand() % 10 + 5;
	food.x = rand() % WIDTH;
	food.y = rand() % HEIGHT;
}

void  GameDraw()
{
	BeginBatchDraw();//��ֹ����
	//���ñ�����ɫ
	setbkcolor(RGB(151,203,208));
	cleardevice();
	//������
	for (int i = 0; i < snake.size; i++)
	{
		setfillcolor(BLACK);
		solidcircle(snake.coor[i].x, snake.coor[i].y, 5);
	}
	//����ʳ��
	if (food.flag)
	{
		solidcircle(food.x, food.y, food.r);
	}
	EndBatchDraw();
}
//�ߵ��ƶ�
void SnakeMove()
{
	//�ƶ�����
	for (int i = snake.size - 1; i > 0; i--)//����ͷ����β
	{
		snake.coor[i] = snake.coor[i - 1];
		//snake.coor[i].x = snake.coor[i - 1].x;
		//snake.coor[i].y = snake.coor[i - 1].y;
	}
	//�ƶ���ͷ
	switch (snake.dir)
	{
	case UP:
		snake.coor[0].y -= snake.speed;
		if (snake.coor[0].y <= 0)
		{
			snake.coor[0].y = HEIGHT;
		}
		break;
	case DOWN:
		snake.coor[0].y += snake.speed;
		if (snake.coor[0].y >=HEIGHT)
		{
			snake.coor[0].y = 0;
		}
		break;
	case LEFT:
		snake.coor[0].x -= snake.speed;
		if (snake.coor[0].x <= 0)
		{
			snake.coor[0].x = WIDTH;
		}
		break;
	case RIGHT:
		snake.coor[0].x += snake.speed;
		if (snake.coor[0].x >= WIDTH)
		{
			snake.coor[0].x= 0;
		}
		break;
	}
}
//�ı��ߵķ���
void keyControl()
{
	if ((GetAsyncKeyState('W') || GetAsyncKeyState(VK_UP))&& snake.dir!=DOWN)
	{
		snake.dir = UP;
	}
	if ((GetAsyncKeyState('S') || GetAsyncKeyState(VK_DOWN)) && snake.dir != UP)
	{
		snake.dir = DOWN;
	}
	if ((GetAsyncKeyState('A') || GetAsyncKeyState(VK_LEFT)) && snake.dir != RIGHT)
	{
		snake.dir = LEFT;
	}
	if ((GetAsyncKeyState('D') || GetAsyncKeyState(VK_RIGHT)) && snake.dir != LEFT)
	{
		snake.dir = RIGHT;
	}
}
void EatFood()
{
	if (snake.coor[0].x>=food.x-food.r&&snake.coor[0].x<=food.x+food.r&& 
		snake.coor[0].y>=food.y-food.r&&snake.coor[0].y<=food.y+food.r&&
		food.flag)
	{
		snake.size++;
		food.flag = 0;
	}
	//���ʳ�ﱻ���ˣ�����������һ��ʳ��
	if (!food.flag)
	{
		food.color = RGB(rand() % 256, rand() % 256, rand() % 256);
		food.flag = 1;
		food.r = rand() % 10 + 5;
		food.x = rand() % WIDTH;
		food.y = rand() % HEIGHT;
	}
}
//ʹ������ͣ
void stop()
{
	if (_kbhit())//����Ƿ��а���
	{
		while (_getch() == ' ')
		{
			while (_getch() != 32);
			break;
		}
	}
}
int main()
{
	initgraph(WIDTH, HEIGHT);
	GameInit();
	DWORD t1, t2;
	t1 = t2 = GetTickCount();
	while (1)
	{
		GameDraw();
		if (t2 - t1 > 200)//���ʱ����ִ�г���
		{
			SnakeMove();
			t1 = t2;
		}
		t2 = GetTickCount();
		keyControl();
		EatFood();
		stop();
		//Sleep(500);
	}
	return 0;
}