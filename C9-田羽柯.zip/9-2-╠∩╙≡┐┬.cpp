#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    int num;           
    int in;     // ָ�����м���   
    char name;          
    int come[10];      
	int aa[10]; 
	char* bb;       
}ljb;

int main(){
    FILE* fp=fopen("p01.txt","r");
    if (fp == NULL){printf("�ļ�p01.txt��ʧ��\n");}
    ljb LJB[100]; 
    int n=0,m;          
    char str[100];
    char* token;
    fgets(str,100,fp);
    while (fgets(str,100,fp)!=NULL){
        token=strtok(str,",");
        LJB[n].name=token[0];
        LJB[n].come[0]=(LJB[n].name-'A'+1);
        m=0;  
        while ((token=strtok(NULL,","))!=NULL){
            if ('A'<=token[0] && token[0]<='Z'){m++;
			LJB[n].come[m]=(token[0]-'A'+1);
						}
        }//�����Ϊ��Ӧ�����ֶ�����come���� 
        LJB[n].num=n;
        LJB[n].in=m;  
        n++;
    }
    
    for(int q=0;q<n;q++){
    	for(int i=0;i<n;i++){
	    	if(LJB[i].come[1]==0&&LJB[i].come[0]!=0){
	    		//printf("%d\n",LJB[i].come[0]);
	    		if(LJB[i].come[0]==1){printf("A\n");}
	    		else if(LJB[i].come[0]==2){printf("B\n");}
	    		else if(LJB[i].come[0]==3){printf("C\n");}
	    		else if(LJB[i].come[0]==4){printf("D\n");}
	    		else if(LJB[i].come[0]==5){printf("E\n");}
	    		else if(LJB[i].come[0]==6){printf("F\n");}
	    		for(int a=0;a<n;a++){
					for(int b=1;b<5;b++){
						if(LJB[a].come[b]==LJB[i].come[0]){
							for(b;b<5;b++){
								LJB[a].come[b]=LJB[a].come[b+1];
								//printf("%d\n",LJB[a].come[b]);
							}
						}
					}
				}
				LJB[i].come[0]=0;
			}
			}
			}
		}
			
