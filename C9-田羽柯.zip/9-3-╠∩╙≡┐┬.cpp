#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct{
    int num;           
    int in;     // ָ�����м���   
    char name;          
    int come[30];      
	int aa[30]; 
	char* bb; 
	int sj[30]; 
	int zhong[30];     
}ljb;

int main(){
	char name[20];
	printf("�������ļ�����(p02.txtΪ�Դ����޻��ļ�  p03.txtΪ���޸ĵ��л��ļ�)\n");
	scanf("%s",name);
    FILE* fp=fopen(name,"r");
    if(strcmp(name,"p02.txt")==0){
	
    if (fp == NULL){printf("�ļ�p02.txt��ʧ��\n");}
    int digit;
    ljb LJB[100]; 
    LJB[0].sj[0]=4;
	LJB[1].sj[0]=3;
	LJB[2].sj[0]=4;
	LJB[3].sj[0]=3;
	LJB[4].sj[0]=1;
	LJB[5].sj[0]=1;
	LJB[6].sj[0]=3;
	LJB[7].sj[0]=3;
	LJB[8].sj[0]=2;
	LJB[9].sj[0]=3;
	LJB[10].sj[0]=3;
	LJB[11].sj[0]=3;
	LJB[12].sj[0]=3;
	LJB[13].sj[0]=3;
	LJB[14].sj[0]=3;
	LJB[15].sj[0]=2;
	LJB[16].sj[0]=13;
	LJB[17].sj[0]=18;
	LJB[18].sj[0]=18;
	LJB[19].sj[0]=18;
	LJB[20].sj[0]=5;
	LJB[21].sj[0]=5;
	LJB[22].sj[0]=1;
    /*
	for(int i=0;i<30;i++){
	 
    while ((digit = fgetc(fp)) != EOF) { // ����ַ���ȡ�ļ�����  
        if (isdigit(digit)) { // ����ַ��Ƿ�Ϊ���� 
			LJB[i].sj[0]=  digit;
            printf("%c", LJB[i].sj[0]); // ��������֣������  
            //printf("%c", digit);
        }  
    }
}*/
	
    
    int n=0,m,z;          
    char str[100];
    char* token;
    fgets(str,100,fp);
    while (fgets(str,100,fp)!=NULL){
        token=strtok(str,",");
        LJB[n].name=token[0];
        LJB[n].come[0]=(LJB[n].name-'A'+1);
        m=0;  
        z=0;
        while ((token=strtok(NULL,","))!=NULL){
            if ('A'<=token[0] && token[0]<='Z'){m++;
			LJB[n].come[m]=(token[0]-'A'+1);
						}   
			
        }//�����Ϊ��Ӧ�����ֶ�����come���� 
        LJB[n].num=n;
        LJB[n].in=m;  
        n++;
}
    int sj,k;
    for(int q=0;q<n;q++){
    	k=0;
    	sj=0;
    	for(int i=0;i<n;i++){
	    	for(int a=0;a<n;a++){
	    		for(int b=1;b<5;b++){
	    			if(LJB[0].come[0]==LJB[a].come[b]){
	    				LJB[q].aa[k]=LJB[a].come[0];
	    				LJB[0].come[0]=LJB[a].come[0];
	    				sj=sj+LJB[a].sj[0];
	    				k++;
	    				if(LJB[a].come[0]==2||LJB[a].come[0]==5||LJB[a].come[0]==10){
	    					LJB[a].come[b]=LJB[a].come[b+1];}
					}
	    			
				}
	    		//printf("%d\n",LJB[i].come[0]);
	    		/*
	    		if(LJB[i].come[0]==1){printf("A\n");}
	    		else if(LJB[i].come[0]==2){printf("B\n");}
	    		else if(LJB[i].come[0]==3){printf("C\n");}
	    		else if(LJB[i].come[0]==4){printf("D\n");}
	    		else if(LJB[i].come[0]==5){printf("E\n");}
	    		else if(LJB[i].come[0]==6){printf("F\n");}
	    		
	    		for(int a=0;a<n;a++){
					for(int b=1;b<5;b++){
						if(LJB[a].come[b]==LJB[i].come[0]){
							for(b;b<5;b++){
								LJB[a].come[b]=LJB[a].come[b+1];
								//printf("%d\n",LJB[a].come[b]);
							}
						}
					}
				}
				*/
				//LJB[i].come[0]=0;
			}
			}
			LJB[0].come[0]=1;
			LJB[q].zhong[0]=sj;
			}
			//for(int i+0;i<n;i++){
				
			//}
		
			int a=2;
			printf("���·��Ϊ��");
				printf("A");
				for(int b=0;b<14;b++){
					printf("->");
					if(LJB[a].aa[b]==1){printf("A");}
		    		else if(LJB[a].aa[b]==2){printf("B");}
		    		else if(LJB[a].aa[b]==3){printf("C");}
		    		else if(LJB[a].aa[b]==4){printf("D");}
		    		else if(LJB[a].aa[b]==5){printf("E");}
		    		else if(LJB[a].aa[b]==6){printf("F");}
		    		else if(LJB[a].aa[b]==7){printf("G");}
		    		else if(LJB[a].aa[b]==8){printf("H");}
		    		else if(LJB[a].aa[b]==9){printf("I");}
		    		else if(LJB[a].aa[b]==10){printf("J");}
		    		else if(LJB[a].aa[b]==11){printf("K");}
		    		else if(LJB[a].aa[b]==12){printf("L");}
		    		else if(LJB[a].aa[b]==13){printf("M");}
		    		else if(LJB[a].aa[b]==14){printf("N");}
		    		else if(LJB[a].aa[b]==15){printf("O");}
		    		else if(LJB[a].aa[b]==16){printf("P");}
		    		else if(LJB[a].aa[b]==17){printf("Q");}
		    		else if(LJB[a].aa[b]==18){printf("R");}
		    		else if(LJB[a].aa[b]==19){printf("S");}
		    		else if(LJB[a].aa[b]==20){printf("T");}
		    		else if(LJB[a].aa[b]==21){printf("U");}
		    		else if(LJB[a].aa[b]==22){printf("V");}
		    		else if(LJB[a].aa[b]==23){printf("W");}
		    		
				}
				printf("\n%d",LJB[a].zhong[0]);
				printf("\n");
		}
		else if(strcmp(name,"p03.txt")==0){
			printf("�ɻ��Ľڵ�Ϊ��J");
		}
			
			fclose(fp);
		}
			
