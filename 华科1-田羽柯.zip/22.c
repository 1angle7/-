#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASTABLE -1
#define OVERFLOW -2
#define NO -1
#define LIST_INIT_SIZE 100
#define LISTINCREMENT 10

typedef int status;
typedef int ElemType; //数据元素类型定义

typedef struct{ //顺序表（顺序结构）的定义
ElemType *elem;
int length;
int listsize;
}SqList;
SqList M[100];

void InitList(SqList*L){
    L->elem=(ElemType*)malloc(LIST_INIT_SIZE * sizeof(SqList));
    //if (L->elem == NULL) {  
        // 如果内存分配失败，则输出错误信息并退出程序  
      //  printf("Memory allocation failed!\n");  
        //exit(EXIT_FAILURE);  
    //}  
    L->length=0;
    printf("线性表创建成功！");
}

void DestroyList(SqList*L){
    free(L->elem);
    L->elem=NULL;
    L->length=0;
    L->listsize=0;
    printf("线性表销毁成功！");
}

void ClearList(SqList*L){
    L->length=0;
    printf("清空线性表！");
}

void ListEmpty(SqList*L){
    if(L->length==0){
        printf("线性表为空！");
    }
    else{
        printf("线性表不为空！");
    }
}

int ListLength(SqList*L){
    printf("线性表的长度为%d!",L->length);
    return L->length;
}

int GetElem(SqList*L){
    int a;
    printf("请输入想要获得元素的位置：");
    scanf("%d",&a);
    printf("第%d的元素为：%d",a,L->elem[a-1]);
    return L->elem[a-1];
}

int LocateElem(SqList*L,int a){
    int i;
    //printf("请输入需要查找的元素：");
    //scanf("%d",&a);
    for(i=0;i<L->length;i++){
        if(a==L->elem[i]){
            printf("第%d个元素与该元素相同",i+1);
            break;
        }
    }
    //else{
    //    printf("无元素与该元素相同");
    //}
    return i;
}

int PriorElem(SqList*L){
    int b;
    int a;
    printf("请输入需要获得其前驱的元素：");
    scanf("%d",a);
    b=LocateElem(L,a);
    if(b==0 || b==ERROR){
        return ERROR;
    }
    else{
        printf("该元素的前驱为%d",L->elem[b-1]);
        return L->elem[b-1];
    }
}

int NextElem(SqList*L){
    int a;
    int b;
    printf("请输入需要获得后驱的元素：");
    scanf("%d",&b);
    a=LocateElem(L,b);
    if(a==L->length-1||a==ERROR){
        return ERROR;
    }
    else{
        printf("该元素后继的元素为%d",L->elem[a-1]);
        return L->elem[a-1];
    }
}

int ListInsert(SqList*L){
    int a;
    int b;
    printf("请依次输入在第_个位置之前插入元素_");
    scanf("%d %d",&a,&b);
    ElemType *newbase;
    ElemType *q,*p;
    ElemType t;
    if(a<1||(a>L->length+1))
        return ERROR;//a 不合法
    if(L->length>=L->listsize){
        newbase=(ElemType*)realloc(L->elem,(L->listsize+LISTINCREMENT)
    * sizeof(ElemType));//增加分配
        if(!newbase)
            exit(OVERFLOW);//存储分配失败
        L->elem=newbase;//新基址
        L->listsize+=LISTINCREMENT;
    }
    q=&(L->elem[a-1]);
    for(p=&(L->elem[L->length-1]);q<=p;p--)
        *(p+1)=*p;//插入位置及之后的元素右移
    L->elem[a-1]=b;
    ++(L->length);
    return OK;
}

status ListDelete(SqList *L,int i,ElemType e){//在顺序线性表中删除第 i 个元素，并用 e 返回其值
    ElemType *q,*p;
    if(i<1||(i>L->length))
        return ERROR;//i 不合法
    e=L->elem[i-1];//被删除元素值赋给 e
    p=L->elem+L->length-1;//令 p 为表尾位置
    for(q=&(L->elem[i]);q<=p;q++)
        *(q-1)=*q;//被删元素之后的元素依次前移
    --(L->length);
    return OK;
}

void ListTraverse(SqList*L){
    for(int i=0;i<L->length;i++){
        printf("%d ",L->elem[i]);
    }
}

status Wirte(SqList L) {
    FILE *fp=NULL;
    char filename[30];
    printf("input file name: ");
    scanf("%s",filename);
    if ((fp=fopen(filename,"wb"))==NULL){
        printf("File open error\n ");
        return FALSE;
    }
    //写文件的方法
    fwrite(L.elem,sizeof(ElemType),L.length,fp);
    //这里是 1 次性写入，对于其它物理结构，
    //也可以先写入表长，再写入全部元素,这样读入会更方便
    fclose(fp);
    return OK;
}

status Read(SqList *L) {
    FILE *fp;
    char filename[30];
    printf("input file name: ");
    scanf("%s",filename);
    //读文件的方法
    L->length=0;
    if ((fp=fopen(filename,"rb"))==NULL){
        printf("File open error\n ");
        return FALSE;
    }
    while(fread(&L->elem[L->length],sizeof(ElemType),1,fp))
    L->length++;
    //这里从文件中逐个读取数据元素恢复顺序表，对于不同的物理结构，
    //可通过读取的数据元素恢复内存中的物理结构。
    fclose(fp);
    return OK;
}
   
int main(){
    int c;
    int d,e,f;
    SqList L;
    while(c!=0){
        printf("\n1.初始化表\t2. 销毁表\n3.清空表\t4.判定空表\n5.求表长\t6.获得元素\n7.查找元素\t8.获得前驱\n9.获得后继\t10.插入元素\n11.删除元素\t12. 遍历表\n13.写入文件\t14.读取文件\n0.退出");
        scanf("%d",&c);
        //c==0;
        switch (c)
        {
        case 0:
            printf("结束");
            break;
        case 1:
            InitList(&L);
            break;
        case 2:
            DestroyList(&L);
            break;
        case 3:
            ClearList(&L);
            break;
        case 4:
            ListEmpty(&L);
            break;
        case 5:
            ListLength(&L);
            break;
        case 6:
            GetElem(&L);
            break;
        case 7:
            printf("请输入需要查找的元素：");
            scanf("%d",&d);
            LocateElem(&L,d);
            break;
        case 8:
            PriorElem(&L);
            break;
        case 9:
            NextElem(&L);
            break;
        case 10:
            ListInsert(&L);
            break;
        case 11:
            printf("删除第几位上面的数字");
            scanf("%d",&e);
            ListDelete(&L,e,f);
            break;
        case 12:
            ListTraverse(&L);
            break;
        case 13:
            Wirte(L);
            break;
        case 14:
            Read(&L);
            break;
        default:
            break;
        }
    }
    return 0;
}



