#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct Student)
struct Student  
	{long num;
    char name[20];
    float score;
    float aver;
    struct Student *next;
	};

struct Student*wj()
{
	FILE*file;
	file = fopen("�ɼ�.txt","r");  //���ļ� 
	if (file == NULL)
	{
		printf("�޷����ļ�\n");
		return NULL;
	}
	
	struct Student*head = NULL;
	char line[100];
	
	while (fgets(line,100,file) !=NULL)
	{
		struct Student *newNode;
		newNode = (struct Student *)malloc(LEN);
			
			if(newNode == NULL)
			{
				printf("����");
				return NULL; 
			}
			
			if(sscanf(line, "%ld %s %f",&newNode->num, newNode->name, &newNode->score) == 3)
			{
				newNode->next = head;
				head = newNode;
			}
			else
			{
				free(newNode);
				break;
			}
	}
	fclose(file);
	return head;   //���ļ��е�����ȫ����file 
}
void xieru(struct Student *head)  
{
	struct Student *current = head;
	while(current != NULL)
	{
		struct Student *temp = current;
		current == current->next;
		free(temp);
	}
}

void jisuan(struct Student *head)  //����ƽ��ֵ 
{
	float sum = 0;
	int count = 0; 
	struct Student *current = head;
	
	while(current !=NULL)
	{
		sum +=current->score;
		count++;
		current = current->next;
	}
	float average = sum/count;
	printf("��ƽ���ɼ��ǣ�%.1f\n",average);
}

void print(struct Student *student)
{
	if (student == NULL)
	{
		printf("����ǿյ�\n");
		return;
	}
	
	struct Student *current = student;
	float max = current->score;
	float min = current->aver;
	
	while (current !=NULL)   //�������Сֵ 
	{
		if (current->score >max)
		{
			max=current->score;
		}
		if (current->score <min)
		{
			min = current->score;
		}
		current = current->next;
	}
	
	current = student;
	while(current !=NULL)  //��ʾ�����Сֵ 
	{
		if (current->score == max)
		{
			printf("�ɼ���ߵ�ѧ���У�%s\n", current->name);
	    	printf("ѧ�ţ�%ld\n������%s\n�ɼ���%.1f\n", current->num, current->name, current->score);
		}
		
		if (current->score == min)	
	    {
	    	// ��ӡ�ɼ���͵�ѧ����Ϣ
	    	printf("�ɼ���͵�ѧ���У�%s\n", current->name);
	    	printf("ѧ�ţ�%ld\n������%s\n�ɼ���%.1f\n", current->num, current->name, current->score);
		}
		
		current = current->next;
	}
}
int main()  //������ 
{
	struct Student*head = wj();
    if (head == NULL)
    {
        return 1;
    }
    print(head);
    jisuan(head);
    xieru(head);
    return 0;
}
